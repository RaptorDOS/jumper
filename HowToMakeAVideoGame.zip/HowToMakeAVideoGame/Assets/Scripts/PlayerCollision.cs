using UnityEngine;

public class PlayerCollision : MonoBehaviour {

	public PlayerMovement movement;
	public Rigidbody mass_change;// A reference to our PlayerMovement scriptf
	public float up_force = 500;

	// This function runs when we hit another object.
	// We get information about the collision and call it "collisionInfo".
	void OnCollisionEnter (Collision collisionInfo)
	{
		// We check if the object we collided with has a tag called "Obstacle".
		if (collisionInfo.collider.tag == "Obstacle")
		{
			movement.enabled = false;   // Disable the players movement.
			FindObjectOfType<GameManager>().EndGame();
			Debug.Log("Hit");
			mass_change.useGravity = false;
			mass_change.AddForce(0,up_force*Time.deltaTime,0,ForceMode.VelocityChange);
		}
	}

}
